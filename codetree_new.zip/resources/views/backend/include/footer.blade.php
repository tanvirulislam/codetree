<footer>
            <div class="footer-area">
                <p>© Copyright 2021. All right reserved. Developed by <a href="https://codetreebd.com/"><b style="color:#6DBD44;">CODETREE</b></a>.</p>
            </div>
        </footer>