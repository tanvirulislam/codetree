<div class="header-area" style="background: linear-gradient(90deg,#0D8D45,#93C13D)">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="search-box pull-left">
                            <form action="#">
                                <input type="text" name="search" placeholder="Search..." required>
                                <i class="ti-search" style="color:white;"></i>
                            </form>
                        </div>
                    </div>
                    <!-- profile info & task notification -->
                    <div class="col-md-6 col-sm-4 clearfix">
                        <ul class="notification-area pull-right">
                            <li id="full-view"><i class="ti-fullscreen" style="color:white;"></i></li>
                            <li id="full-view-exit"><i class="ti-zoom-out" style="color:white;"></i></li>
                            
                           
                            
                        </ul>
                    </div>
                </div>
            </div>