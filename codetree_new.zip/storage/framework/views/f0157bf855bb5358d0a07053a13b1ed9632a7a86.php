<div id="banner">
      <div class="container">
        <div class="banner-container">
          <div
            class="banner-content"
            data-aos="fade-up"
            data-aos-duration="1200"
          >
          <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1>WE CODE BETTER <span class="primary-color">LIFE</span></h1>
            <p>
             <?php echo e($banner->des); ?>

            </p>
            <a
              href="<?php echo e($banner->link); ?>"
              target="_blank"
              class="btn btn-transparent"
              ><?php echo e($banner->btitle); ?></a
            >
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>

    <div class="player2">
      <video
        class="player__video2 viewer"
        src="<?php echo e(asset('/')); ?>public/front/img/Video.m4v"
        loop
        autoplay
        muted
      ></video>
    </div><?php /**PATH C:\xampp\htdocs\codetree_new\resources\views/front/include/banner.blade.php ENDPATH**/ ?>