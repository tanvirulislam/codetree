<nav id="header" class="main-nav">
      <div class="header container">
        <?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('/')); ?><?php echo e($logo->image); ?>" class="logo" /></a>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="nav-list">
          <div class="hamburger"><div class="bar"></div></div>
          <ul>
            <li>
                
            <a class="<?php echo e(Request::is('/') ? 'current' : ''); ?>" href="<?php echo e(route('index')); ?>" data-after="Home">Home</a>
            </li>
            <li class="dropdown" id="drop1">
              <a class="dropbtn skip" onclick="toggleNav1()" data-after="Software">
               <?php echo e($software); ?>

              </a>
              <div class="dropdown-content">
                <a href="<?php echo e(route('Pos&Inventory')); ?>">Pos & Inventory</a>
                <a href="<?php echo e(route('school&management')); ?>">School & College Management</a>
              </div>
            </li>
            <li class="dropdown" id="drop2">
              <a class="dropbtn skip" onclick="toggleNav2()"  data-after="Services" class="<?php echo e(Request::is('service*') || Request::is('bulk-sms') || Request::is('hosting')  ? 'current' : ''); ?>"  >Services</a>
              <div class="dropdown-content">
                 <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('service',$service->slug)); ?>"><?php echo e($service->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('bulk-sms')); ?>">Bulk Sms</a>
                 <a href="<?php echo e(route('hosting')); ?>">Cloud Hosting</a>
              </div>
            </li>
            <li>
              <a href="<?php echo e(route('portfolio')); ?>" class="<?php echo e(Request::is('all/portfolio') ? 'current' : ''); ?>"  data-after="Portfolio">Portfolio</a
              >
            </li>
            <li>
              <a href="<?php echo e(route('news')); ?>" class="<?php echo e(Request::is('news') ? 'current' : ''); ?>" data-after="News" >News</a>
            </li>
            <li>
              <a href="<?php echo e(route('about')); ?>" data-after="About" class="<?php echo e(Request::is('about') ? 'current' : ''); ?>">About</a
              >
            </li>
            <li>
              <a href="<?php echo e(route('team')); ?>" data-after="Team" class="<?php echo e(Request::is('team') ? 'current' : ''); ?>">Team</a>
            </li>
            <li>
              <a href="<?php echo e(route('contact')); ?>" data-after="Contact" class="<?php echo e(Request::is('contact') ? 'current' : ''); ?>">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav><?php /**PATH C:\xampp\htdocs\codetree_new\resources\views/front/include/header.blade.php ENDPATH**/ ?>