  

  <?php $__env->startSection('title'); ?>
Home | Codetree
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('body'); ?>
<!--banner section -->
<?php echo $__env->make('front.include.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--banner section -->
<section id="about" class="py-3">
      <div class="container" data-aos="fade-up" data-aos-duration="1200">
        <div class="about-header">
          <h1 class="l-heading uppercase">Why choose us?</h1>
          <?php $__currentLoopData = $chooseTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p>
            <?php echo e($title->htitle); ?>

          </p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="about-cards py-1">
          
          
         <?php $__currentLoopData = $chooses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card">
            <div class="card-icon">
              <i class="<?php echo e($choose->Icon); ?> text-center"></i>
            </div>
            <div class="card-content">
              <div class="card-title">
                <h2>0<?php echo e($loop->index+1); ?></h2>
                <h2><?php echo e($choose->title); ?></h2>
              </div>
              <div class="card-text">
                <p>
                 <?php echo e($choose->des); ?>

                </p>
              </div>
            </div>
          </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
      </div>
    </section>

    <section id="features" class="py-4">
      <div class="container" data-aos="fade-up" data-aos-duration="1200">
        <div class="features-container">
          <div class="features-header py-1">
            <h1 class="l-heading text-center uppercase">Awesome Featuress</h1>
            <?php $__currentLoopData = $featureTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-center">
              <?php echo e($title->htitle); ?>

            </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="features-cards about-cards">

            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="card">
              <div class="card-icon">
                <i class="<?php echo e($feature->Icon); ?>"></i>
              </div>
              <div class="card-content">
                <div>
                  <h2><?php echo e($feature->title); ?></h2>
                </div>
                <div class="card-text">
                  <p>
                    <?php echo e($feature->des); ?>

                  </p>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
            
           
           

          </div>
        </div>
      </div>
    </section>

    <!-- Divider -->
    <!-- Divider -->
    <!-- Divider -->
    <section id="divider-section">
      <div class="container">
        <div class="divider">
          <h2>Find Us On</h2>
          <ul class="list-social">

            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e($social->link); ?>" target="_blank"
                ><i class="<?php echo e($social->Icon); ?>"></i
              ></a>
            </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </ul>
        </div>
      </div>
    </section>
    <!-- <h2>Our Clients</h2> -->
    <!-- Divider -->
    <!-- Divider -->
    <!-- Divider -->

    <!-- <section id="portfolio" class="py-4">
    </section> -->

    <section id="client" class="py-3">
      <div class="container" data-aos="fade-up" data-aos-duration="1200">
        <div class="client-container">
          <div class="client-header py-1">
            <h1 class="l-heading uppercase">Trusted Since 2017</h1>
            <p>Clients we worked with</p>
          </div>
          <div class="client-content-background">
            <div class="client-content">
              <div class="glide" id="glide_5">
                <div class="glide__track" data-glide-el="track">
                  <ul class="glide__slides">

                    <li class="glide__slide">
                      <div class="card-wraper">
                        <?php $__currentLoopData = $firstSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $first): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                          <img src="<?php echo e(asset('/')); ?><?php echo e($first->image); ?>" alt="" />
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                      </div>
                    </li>
                    <li class="glide__slide">
                      <div class="card-wraper">
                        <?php $__currentLoopData = $secondSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $first): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                          <img src="<?php echo e(asset('/')); ?><?php echo e($first->image); ?>" alt="" />
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </li>
                    <li class="glide__slide">
                      <div class="card-wraper">
                        <?php $__currentLoopData = $thirdSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $first): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                          <img src="<?php echo e(asset('/')); ?><?php echo e($first->image); ?>" alt="" />
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonial -->
    <section class="section testimonial" id="testimonial">
      <div
        class="testimonial__container"
        data-aos="fade-up"
        data-aos-duration="1200"
      >
        <div class="glide" id="glide_3">
          <div class="glide__track" data-glide-el="track">
            <ul class="glide__slides">
              <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="glide__slide">
                <div class="testimonial__box">
                  <div class="client__image">
                    <img src="<?php echo e(asset('')); ?><?php echo e($client->image); ?>" alt="" />
                  </div>
                  <p>
                    <i class="fas fa-quote-left"></i>
                          <?php echo e($client->com); ?>

                    <i class="fas fa-quote-right"></i>
                  </p>
                  <div class="client__info">
                    <h3><?php echo e($client->name); ?></h3>
                    <span><?php echo e($client->title); ?> at <a href="<?php echo e($client->link); ?>" style="color:white;"><?php echo e($client->c_name); ?></a></span>
                  </div>
                </div>
              </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            
            </ul>
          </div>
          <div class="glide__bullets" data-glide-el="controls[nav]">
            <button class="glide__bullet" data-glide-dir="=0"></button>
            <button class="glide__bullet" data-glide-dir="=1"></button>
            <button class="glide__bullet" data-glide-dir="=2"></button>
            <button class="glide__bullet" data-glide-dir="=3"></button>
          </div>
        </div>
      </div>
    </section>
    <!-- Testimonial -->

    <!-- News -->
    <div id="news" class="news__container">
      <div class="container" data-aos="fade-up" data-aos-duration="1200">
        <div class="news-container-background">
          <div class="news-header">
            <h1>News</h1>
            <p>Stay connected & get the latest news about us.</p>
          </div>
          <div class="glide" id="glide_4">
            <div class="glide__track" data-glide-el="track">
              <ul class="glide__slides">

<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="glide__slide">
                  <div class="new__card">
                    <div class="card__header">
                      <img src="<?php echo e(asset('/')); ?><?php echo e($new->image); ?>" alt="" />
                      <a class="btn btn-transparent" href="http://"
                        ><?php echo e($new->title); ?></a
                      >
                    </div>
                  </div>
                </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
              </ul>
            </div>
          </div>
          <div class="news__footer">
            <a
              href="<?php echo e(route('news')); ?>"
              target="_blank"
              class="btn btn-transparent"
              >See All</a
            >
          </div>
        </div>
      </div>
    </div>
    <!-- News -->

    <section id="share-idea">
      <div class="share-idea-container">
        <div
          class="share-idea-content py-1"
          data-aos="fade-up"
          data-aos-duration="1200"
        >
          <h1 class="l-heading uppercase">SHARE YOUR IDEAS WITH US</h1>
          <p>
            Software Development, Website Design, Mobile Application & Digital
            Marketing Solution
          </p>
          <a class="btn btn-transparent">Call Us +88 0171-007-0606</a>
        </div>
      </div>
    </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codetree_new\resources\views/front/index.blade.php ENDPATH**/ ?>