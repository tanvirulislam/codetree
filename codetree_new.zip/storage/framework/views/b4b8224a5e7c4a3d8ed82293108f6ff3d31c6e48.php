<footer id="main-footer" class="py-4">
      <div class="container" data-aos="fade-up" data-aos-duration="1200">
        <div class="footer-content py-1">
          <div class="content-left">
            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><?php echo e($address->title); ?></h2>
            <p>
              <?php echo e($address->des); ?>

            </p>
            <ul class="list-contact">
              <li>
                <i class="far fa-envelope"></i>
                <?php echo e($address->email); ?>

              </li>
              <li><i class="fas fa-mobile-alt"></i><?php echo e($address->phone); ?></li>
              <li>
                <i class="fas fa-map-marker-alt"></i>
                <?php echo e($address->add); ?>

              </li>
            </ul>
             <?php if(Request::is('hosting') || Request::is('cloud-description') ): ?>
             
             <?php elseif(Request::is('bulk-sms')): ?>
             
             <?php else: ?>
            <iframe
              src="<?php echo e($address->loaction); ?>"
              id="map"
              frameborder="0"
              style="border: 0"
              allowfullscreen=""
              aria-hidden="false"
              tabindex="0"
            ></iframe>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="content-right">
              <?php if(Request::is('hosting') || Request::is('cloud-description')): ?>
              <h3>Our affiliated partner</h3>
            <img src="<?php echo e(asset('/')); ?>public/front/img/qan.png" alt="" />
              <?php elseif(Request::is('bulk-sms')): ?>
              <h3>OUR AFFILIATED PARTNER</h3>
              <img src="<?php echo e(asset('/')); ?>public/front/img/sms.png" alt="" />
              <?php else: ?>
             <h3>SAY SOMETHING</h3>
            <input type="text" placeholder="Your Name" />
            <input type="email" placeholder="Your Email" />
            <textarea
              name="message"
              id="message"
              cols="30"
              rows="10"
              placeholder="Write your message"
            ></textarea>
            <button type="submit" class="btn">Send</button>
            <?php endif; ?>
          </div>
        </div>
        <div class="footer-end">
          <p>&copy;2017 - <span id="year"></span> Copyright <b>CODETREE</b></p>
          <ul class="list-social">
             <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e($social->link); ?>" target="_blank"
                ><i class="<?php echo e($social->Icon); ?>"></i
              ></a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <ul class="list-col">
             <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a
                href="<?php echo e($address->term); ?>"
                target="_blank"
                >Terms & Conditions</a
              >
            </li>
           <!-- <li>
              <a href="https://www.facebook.com/codetreebd" target="_blank"
                ><b>CODETREE</b></a
              >
            </li>-->
            <li>
              <a
                href="<?php echo e($address->locationlink); ?>"
                target="_blank"
                >Location</a
              >
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
    </footer><?php /**PATH C:\xampp\htdocs\codetree_new\resources\views/front/include/footer1.blade.php ENDPATH**/ ?>