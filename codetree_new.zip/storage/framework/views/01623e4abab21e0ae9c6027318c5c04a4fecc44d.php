<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/')); ?><?php echo e($icon->image); ?>">
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/
    ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
      integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/"
      crossorigin="anonymous"
    />
    <script
      src="https://kit.fontawesome.com/23f1789103.js"
      crossorigin="anonymous"
    ></script>
    <link
      rel="stylesheet"
      href="<?php echo e(asset('/')); ?>public/front/node_modules/@glidejs/glide/dist/css/glide.core.min.css"
    />
    <link
      rel="stylesheet"
      href="<?php echo e(asset('/')); ?>public/front/node_modules/@glidejs/glide/dist/css/glide.theme.min.css"
    />

    

    <!-- Animate On Scroll -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/front/css/style.css" />
    <link
      rel="stylesheet"
      media="screen and (max-width: 768px)"
      href="<?php echo e(asset('/')); ?>public/front/css/mobile.css"
    />
    
    <!-- toastr -->
    <link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    <title><?php echo $__env->yieldContent('title'); ?></title>
   <?php echo $__env->yieldContent('style'); ?>
  </head>
  <body>
    <!--for page plugin-->
    <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v9.0&appId=163021345139001&autoLogAppEvents=1" nonce="uEQVY1pO"></script>
    <!--for page plugin-->
    <!--header-section-->
    <?php echo $__env->make('front.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--header-section-->
    <!-- Showcase -->
    

    <?php echo $__env->yieldContent('body'); ?>

    <!--footer-->
<?php echo $__env->make('front.include.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!--footer-->

    <!-- Glidejs -->
    <script src="<?php echo e(asset('/')); ?>public/front/node_modules/@glidejs/glide/dist/glide.min.js"></script>
    <!-- Animate On Scroll AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/front/js/app.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/front/js/slider.js"></script>
 <div id="fb-root"></div>
 <!-- toastr -->
 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
 <script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
        <?php echo Toastr::message(); ?>

           <script>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              toastr.error('<?php echo e($error); ?>','Error',{
                  closeButton:true,
                  progressBar:true,
               });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>

      <script>
        window.fbAsyncInit = function() {
          FB.init({
               appId            : '2431386933747937',
             autoLogAppEvents : true,
            xfbml            : true,
            version          : 'v5.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="809832952505565"
  theme_color="#67b868">
      </div>
      <?php echo $__env->yieldContent('script'); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\codetree_new\resources\views/front/master/master.blade.php ENDPATH**/ ?>